def mainBoi():



def getItems():
    userInput = input("Please input the item's price\n> ")

while keepGoing > 0:
    asdfsaf
numItems = len(itemList)
subTotal = sum(float(itemList))
salesTheft = .06*subTotal
grandTotal = subTotal+salesTheft

print('''    Sales Receipt
Number of items: %i
     Sub Total: $%f
     Sales Tax: $%f

        Total: $%f''') % (numItems, subTotal, salesTheft, grandTotal)










def name() :
    asdsaf
    asdfsadf
    sdafsdf

name()


show_double(value)

def show_double(number):
    result = number * 2


