'''multiple
line
string'''

print(floatVar, format(.2f))