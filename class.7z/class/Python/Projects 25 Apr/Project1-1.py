import pet

def main():
    print("Let's get this human a pet")
    petName = input("Please name your pet\n> ")
    petType = input("What type of pet is it?\n> ")
    petAge = int(input("How old is it?\n> "))

    yourPet = Pet(name, animal_type, age)


    print("Here's your new pet!")
    print("Name: %s" %(pet.get_name))
    print("Name: %s" %(pet.get_type))
    print("Name: %s" %(pet.get_age))

main()
