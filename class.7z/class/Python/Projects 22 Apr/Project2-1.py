def show_value():
    result = times_ten(12)
    print(result)

def times_ten(inputNum):
    bigger = inputNum*10
    return bigger

show_value()
