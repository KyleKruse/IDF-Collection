def mainBoi():
    print("Why would you even measure in kilometers in the first place?")
    kilos = float(input("Whatever, just gimme those non-free digits\n> "))
    miles = calcuBoi(kilos)
    print("%.2f KiloNotFreeMeters is about the same distance as %.2f miles. #murica" % (kilos, miles))

def calcuBoi(pre):
    post = pre*0.6214
    return post

mainBoi()
