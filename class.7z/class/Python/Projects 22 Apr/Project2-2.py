# We drawin things
def draw_diamond():
    print("This is a diamond\n")
    tri_up()
    tri_down()
    print()

def draw_x():
    print("This is an X\n")
    tri_down()
    tri_up()
    print()

def draw_rocket():
    print("THIS IS A ROCKET BOIS")
    print('''#murica #feelingspacey #feelingspicymorelikeit
#nextstoppluto #plutolivesmatter #space\n''')
    tri_up()
    hull()
    text()
    hull()
    tri_up()
    print()

#These are all the individual components
def tri_up():
    print("   /\\")
    print("  /  \\")
    print(" /    \\")

def tri_down():
    print(" \\    /")
    print("  \\  /")
    print("   \\/")

def hull():
    print("+------+")
    print("|      |")
    print("|      |")
    print("+------+")

def text():
    print("|United|")
    print("|States|")

draw_diamond()
draw_x()
draw_rocket()
