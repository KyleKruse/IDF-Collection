def mainBoi():
    print("Welcome to you friendly neighborhood tax calculator, featuring automatic IRS notifications")
    getNums()
    print("\nThank you come again")

def getNums():
    sales = float(input("What was the total sales for the month?\n> "))
    county = float(input("What is the county tax rate?\n> "))
    state = float(input("What is the state tax rate?\n> "))
    print("\nHere's the tax breakdown for a monthly sales figure of $%.2f" % (sales))
    maths(sales, county, state)

def maths(sales, county, state):
    countyTax = sales*county
    stateTax = sales*state
    totalTax = countyTax+stateTax
    printyBoi(countyTax, stateTax, totalTax)

def printyBoi(countyTax, stateTax, totalTax):
    print('''
    County sales tax: $%.2f
     State sales tax: $%.2f
     Total sales tax: $%.2f''' % (countyTax, stateTax, totalTax))
    
mainBoi()
