def mainBoi():
    print("This is your fat/carb calorie calculator version 0.69.420")
    getNums()
    print("\"Remember, with great power comes great chance to lose your uncle Ben.\"\n - Christopher Columbus")

def getNums():
    fats = int(input("How many grams of fat do you consume in a day?\n> "))
    carbs = int(input("How many grams of carbs do you consume in a day?\n> "))
    mathsThings(fats, carbs)

def mathsThings(fats, carbs):
    calFat = fats*9
    calCarbs = carbs*4
    print("The resulting calories are:\nFat: %i\nCarbs: %i" % (calFat, calCarbs))

mainBoi()
