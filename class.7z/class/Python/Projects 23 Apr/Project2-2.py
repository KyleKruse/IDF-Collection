def isPalindrome():
    string1 = input("Enter a number you'd like to check\n> ")
    string2 = reverse(string1)
    if string1 == string2:
        print("That's a palindrome")
        return True
    else:
        print("That's not a palindrome")
        return False

def reverse(string1):
    return string1[::-1]

isPalindrome()
