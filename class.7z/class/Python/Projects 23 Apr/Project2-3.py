def reverse():
    string1 = input("Gimme an int to reverse\n> ")
    print("Reversed --> %s" % (string1[::-1]))

reverse()
