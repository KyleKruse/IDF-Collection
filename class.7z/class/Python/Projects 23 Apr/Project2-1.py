def hexxx():
    thing = hex(int(input('Enter an integer\n> ')))
    print(thing)
hexxx()
