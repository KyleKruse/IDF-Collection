

height = int(input("What is your height?\n> "))
color = input("What is your favorite color?\n> ")
print("You're %i inches tall and enjoy the color %s" %(height, color))

a = 0
b = a+2
a = b*4
b = a/3.14
a = b-8

print(a)
print(b)

input()