def backwardsBoi():
    from os import getcwd
    path = getcwd() + "\\words.txt"
    
    inFile = open(path)
    wordsList = inFile.readlines()
    inFile.close()

    index = 0
    while index < len(wordsList):
        wordsList[index] = wordsList[index].rstrip("\n")
        index += 1
    
    revList = []
    for i in range(0, len(wordsList)):
        new = wordsList[i]
        revList.append(new[::-1])

    outFile = open(path, "w")

    for i in revList:
        outFile.write(str(i) + "\n")

    outFile.close()

    print(wordsList)
    print()
    print(revList)

backwardsBoi()
