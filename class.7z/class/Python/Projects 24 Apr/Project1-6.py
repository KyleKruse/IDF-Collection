def zwanzigBoi():
    userNums = input("Please give me 20 numbers, separated with a space:\n> ")
    listNums = userNums.split()
    lowNum = min(map(int, listNums))
    highNum = max(map(int, listNums))
    totNum = sum(map(int, listNums))
    avgNum = totNum / 20

    print("The lowest number in the list is: %d" % (lowNum))
    print("The highest number in the list is; %d" % (highNum))
    print("The total of the numbers is: %d" % (totNum))
    print("The average number is: %.0f" % (avgNum))

zwanzigBoi()
    
