def rainyBoi():
    months = ["January", "February", "March", "April", "May", "June",
              "July", "August", "September", "October", "November", "December"]
    rainfall = []

    for i in range(0,12):
        print("Please enter the amount of rainfall for %s" % (months[i]))
        rainfall.append(input())

    totRain = sum(map(int, rainfall))
    avgRain = totRain / 12
    minRain = months[rainfall.index(min(rainfall))]
    maxRain = months[rainfall.index(max(rainfall))]

    if len(rainfall) > 0:
        print("The total rain for the year is: %d" % (totRain))
        print("The average rain for the year is: %0.2f" %(avgRain))
        print("The month with the least rain was: %s" %(minRain))
        print("The month with the most rain was: %s" %(maxRain))

rainyBoi()
