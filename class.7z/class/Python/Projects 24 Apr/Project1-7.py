def salesBoi():
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    sales = []

    for i in range(0,7):
        print("Please enter the sales for %s" % (days[i]))
        sales.append(input())

    totSales = sum(map(int, sales))

    if len(sales) > 0:
        print("The total sales for the week was: $%i" % (totSales))

salesBoi()
