import random

def lotteryBoi():
    ticket = []

    for i in range(0,7):
        ticket.append(random.randint(0,9))

    if len(ticket) > 0:
        print("Your lottery ticket is:")
        print("".join(str(x) for x in ticket))
    else:
        print("No lottery for you")

lotteryBoi()
