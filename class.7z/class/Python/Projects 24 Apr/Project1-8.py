def hangyBoi():
    word = ["D", "A", "N", "K"]
    letters = []
    shown = ["_", "_", "_", "_"]
    tries = 5
    guess = ""
    winner = 0
    print("You have 10 tries to guess the word. Ready go!")
    
    while tries > 0:
        if shown == word:
            tries = 0
            winner = 1
            break

        print("\n\n\n\n\n##### HANGYBOI ##### Tries left: %d\n" % (tries))
        print(*shown, sep = " ")
        print("\nLetters Guessed:")
        print(*letters, sep = ", ")
        print()

        guess = (input("Choose a letter\n> "))
        guess = guess.capitalize()
        if guess in letters:
            print("\nThat's been guessed already, try again")

        elif guess in word:
            print("\nNice")
            letters.append(guess)
            for i in range(0, len(word)):
                if guess == word[i]:
                    shown[i] = guess
            
        else:
            print("\nYou suck m8")
            letters.append(guess)
            tries -= 1
    if winner > 0:
        print("\n\n\n#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*")
        print("\n  Congratulations, you won!  \n")
        print("#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*")
    else:
        print("\n\n\nBetter luck next time...")

hangyBoi()
