def multiDimensionalBoi():
    # Create an empty m x n array
    m = 5
    n = 3
    wack = [["" for x in range(n)] for x in range(m)] 
    print("Here's your empty 5x3 array:")
    print(wack, "\n")

    # Replace 0's with user's choice of numbers
    for i in range(len(wack)):  
        for j in range(len(wack[i])):  
            wack[i][j] = input("Number plox\n> ")

    # Show off the goods
    print("And here it is with all your numbers:")
    print(wack)

multiDimensionalBoi()
