def rubyBoi():
    names = ["Einstein", "Newton", "Copernicus", "Kepler"]

    if "Ruby" in names:
        print("Hello Ruby")
    else:
        print("No Ruby")

rubyBoi()
