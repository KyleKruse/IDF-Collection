def smartBois():
    names = ["Einstein", "Newton", "Copernicus", "Kepler"]
    for i in range(0,(len(names))):
        print(names[i])

smartBois()
