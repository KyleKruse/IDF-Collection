totalSales = float(input("What is the projected total sales?\n> "))
profit = totalSales * .23

print("The estimated profit is $%.2f" % (profit))
