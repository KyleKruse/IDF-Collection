def decodeMorse(morse_code):
    morseList = [".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..", "--", "-.", "---", ".--.", "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--.."]

    morse_code



    writelines
    readlines
    outfile = open("citie.txt", "r")
    fromFile = readlines(outfile)


    scores[0][0] <- 2d list
