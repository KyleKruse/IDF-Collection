/* This is a test for the \a audible alert for printf.
*
*  Name: Kyle Kruse
*  Date: 05 Feb 2019
*  Project: Audbile Alert
*
*/
#include <stdio.h>
#include <conio.h>
#include <time.h>

int main(void)
{
    clock_t startTime = clock();
   
    while(kbhit() == 0);
        while(clock() < startTime + 5);
        printf("Beep \n \a");
        delay(5);

    return 0;
}