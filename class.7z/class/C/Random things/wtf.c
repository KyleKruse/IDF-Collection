
#include <stdlib.h>
#include <stdio.h>


int decodeFromFile(char* filename, unsigned int sizeOfData, unsigned char key, void** buffPtr);

int main(void)
{
    char* filename = "sweg.txt";
    unsigned int sizeOfData = 10;
    unsigned char key = "x";
    void** buffPtr = 69;

    decodeFromFile(filename, sizeOfData, key, buffPtr);
}

int decodeFromFile(char* filename, unsigned int sizeOfData, unsigned char key, void** buffPtr)
{
	int status = ERROR_SUCCESS; // May want to replace this at some point >> Thug life

	if (filename && sizeOfData && key && buffPtr)
	{
		int *myBuffer;
		myBuffer = (char*)malloc(sizeOfData * sizeof(char));

		if (myBuffer != 0) // test if the buffer was made
		{
			FILE *openTest_ptr = fopen(filename, "r");
			if (openTest_ptr != NULL) // test opening the file
			{
				// steal stuff from file into buffer
				int i = 0;

				for (i = 0; i < sizeOfData; i++)
				{

					fscanf(openTest_ptr, "%c", &myBuffer[i]);
				}

				fclose(openTest_ptr); // Always fclose anything you fopen
				
				// reverse that XOR 
				for (i = 0; i < sizeOfData; i++)
				{

					myBuffer[i] = myBuffer[i] ^ key;
				}

				// reassign pointer
				buffPtr = *myBuffer;
			}

			else // file couldn't be opened or doesn't exist
			{
				status = ERROR_OPEN_FAILED;
			}
		}

		else // buffer couldn't be allocated
		{
			status = ERROR_OUTOFMEMORY;
		}
	}

	else // wonky input
	{
		status = ERROR_INVALID_PARAMETER;
	}

	return status;
}