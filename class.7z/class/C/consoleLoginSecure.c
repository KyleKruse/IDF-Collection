#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//SECURE VERSION
//Use fgets, strncmp
int main()
{
    char password[] = "sand";
    char input[15];
    int match;
    print("Password: ");
    scanf("%s", input);

    match = strcmp(input, password);
    if (match ==0)
    {
        puts("Password accepted");
    }
    else
    {
        puts("Invalid password");
    }
    return 0;
}
