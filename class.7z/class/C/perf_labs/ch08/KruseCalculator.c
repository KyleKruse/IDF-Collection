/*
    Create the following functions:
        main():
            This should be what runs your ui, asks for user input, checks for errors/input and runs the needed functions
        add()
            This should add two numbers together
        subtract()
            This should subtract two numbers
        divide()
            This should divide two numbers
        multiply()
            This should multiply two numbers
    Check for errors and valid user input
    Make the program loop
* 
*  Name: Kyle Kruse
*  Date: 12 Feb 2019
*  Project: Calculator
*
*/
#include <stdio.h>

int add(int num1, int num2);
int subtract(int num1, int num2);
int multiply(int num1, int num2);
float divide(float num1, float num2);

int main(void)
{
    int userNum1 = 0;
    int userNum2 = 0;
    char mathSign = 0;
    float answer = 0;
    char userYesNo;
    int userContinue = 1;
    int ansAvail = 0; //True/False if math function was performed
    int numValid = 0; //True/False if number input is valid
    

    //Welcome message
    fprintf(stdout, "Welcome to the Kruse potato-calc, featuring nothing related to the ground starch. \n");

    //Main program loop
    while (userContinue == 1)
    {
        //Instruction + prompt user for math equation
        fprintf(stdout, "Available functions are: addition, subtraction, multiplication, and division. \n");
        fprintf(stdout, "Please input a math equation you'd like to solve (Example '1 + 2'): \n");
        
        //Warning for letters. Remove once proper input validation is implemented.
        fprintf(stdout, "!!! WARNING !!! \n"); 
        fprintf(stdout, "DO *NOT* ENTER A LETTER. IT WILL BREAK. \n"); 
        
        //Obtains user input
        fscanf(stdin, "%i %c %i", &userNum1, &mathSign, &userNum2);

        //User input error handing here
        //#thuglife
        numValid = 1;

        //Will continue to math switches if numbers input are valid
        if (numValid > 0)
        {
            //Switches to point to desired math function
            switch (mathSign)
            {   //Addition
                case '+':
                    answer = add(userNum1, userNum2);
                    ansAvail = 1;
                    break;
        
                //Subtraction
                case '-':
                    answer = subtract(userNum1, userNum2);
                    ansAvail = 1;
                    break;
        
                //Multiplication
                case '*':
                    answer = multiply(userNum1, userNum2);
                    ansAvail = 1;
                    break;
        
                //Division
                case '/':
                    answer = divide(userNum1, userNum2);
                    ansAvail = 1;
                    break;

                //Default break
                default:
                    fprintf(stdout, "ERROR: The math function you've provided is either incorrect or unsupported. \n");
                    ansAvail = 0;
                    break;
            }
        }
        //Answer return & prompt user if they want to continue. ONLY IF THE MATH FUNCTION WAS PERFORMED.
        if (ansAvail > 0)
        {
            fprintf(stdout, "------------------------------- \n");
            fprintf(stdout, "// Your answer is: %.2f \n", answer);
            fprintf(stdout, "------------------------------- \n");
            fprintf(stdout, "Would you like to continue? (y)es or (n)o? \n");
            
            //Asks user for continue, "Y" or "y" for yes. Anything else for no
            fscanf(stdin, "%s", &userYesNo);
            if (userYesNo == 'Y' || userYesNo == 'y')
            {
                userContinue = 1;
            }
            else
            {
                userContinue = 0;
            }
            
        }
        
    }
    fprintf(stdout, "Well, that's all the math for today! \n");
    
    return 0;
}

//Addition function
int add(int num1, int num2)
{
    int result = (num1 + num2);
    return result;
}
//Subtraction function
int subtract(int num1, int num2)
{
    int result = (num1 - num2);
    return result;
}
//Multiplication function
int multiply(int num1, int num2)
{
    int result = (num1 * num2);
    return result;
}
//Division function
float divide(float num1, float num2)
{
    float result = (num1 / num2);
    return result;
}