/* int replace_character(char * string, const char findThisChar, const char replaceItWithThis);
*  Return Value - number of characters replaced
*  Parameters:           
                Pointer to a null-terminated string
                Character to find
                Character to replace it with
*  Purpose - replace all occurrences of findThisChar with replaceItWithThis
*  Use pre-defined return values as indicated in shell code
* 
*  Name: Kyle Kruse
*  Date: 11 Feb 2019
*  Project: Performance Lab 8a
*
*/
#include <stdio.h>

int replace_character(char * string, const char findThisChar, const char replaceItWithThis);

int main(void)
{
    char string[64] = {"Every day I'm hustling\0"};
    char findThisChar = " ";
    char replaceItWithThis = "_";
    char answer = 0;
    
    answer = replace_character(string, findThisChar, replaceItWithThis);
    fprintf(stdout, "The answer is: \n%s", answer);
    
    return 0;
}

int replace_character(char * string, const char findThisChar, const char replaceItWithThis)
{
    int replaced[64] = {0};
    int i = 0;
    int num = 0;
    while (string[i] != "\0")
    {
        if (string[i] == findThisChar)
        {
            replaced[i] = replaceItWithThis;
            num++;
            i++;
        }
        else
        {
            replaced[i] = string[i];
            i++;
        }
    }

    return 0;
}