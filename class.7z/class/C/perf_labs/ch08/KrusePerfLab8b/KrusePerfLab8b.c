/* 

    Utilize MyStringHeader.h from the demo lab
    Add the following to MyStringHeader.h

        int reverse_it(char * forwardString, int strLen);

    Return Value
        0 on success
        -1 forwardString is NULL
        -2 if strLen is zero or less
    Parameters - A non-NULL terminated string and the length of that string
    Purpose - Print a non-null terminated string backwards and then print a newline
        Write a program that reads a string from user input, call reverse_it(), and then call print_the_count()
        When satisfied, run "Unit Test Code 2.c"

*  Name: Kyle Kruse
*  Date: 12 Feb 2019
*  Project: Performance Lab 8b
*
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>

#define ERR_NULL_POINTER -1;        // string is null
#define ERR_INVALID_LENGTH -2;      // string length is zero or less

int reverse_it(char * forwardString, int strLen);

int main(void)
{
    char teststring = "This is a test";
    char length = strlen(teststring);
    char result = reverse_it(teststring, length);

    printf("%s", result);
}


reverse_it(char * forwardString, int strLen)
{
    int count = 0;
    char reversed = 0;

    //Error handling for string input
    if (!forwardString)
    {
        return ERR_NULL_POINTER;
    }
    else if (!strLen)
    {
        return ERR_INVALID_LENGTH;
    }

    for (int i = 0; i < strLen; i++)
    {
        
    }

    return reversed;
}