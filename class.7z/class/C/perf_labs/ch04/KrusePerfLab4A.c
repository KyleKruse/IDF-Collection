/* This will take an input of one character and outpet the next sequential character.
* Utilizes getchar() and putchar()
*
*  Name: Kyle Kruse
*  Date: 04 Feb 2019
*  Project: Performance Lab 4A
*
*/
#include <stdio.h>

int main(void)
{
    int userIn = 0;                             //Sets variable//
	printf("Enter a single character: \n");     
    userIn = getchar();                         //Gets the ASCII code for the first inputted character//
	printf("The next character is: \n");
    putchar(userIn + 1);                        //Prints the next sequential ASCII character//

	return 0;
}