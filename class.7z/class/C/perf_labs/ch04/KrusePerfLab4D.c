/* Part 1 will take a 3-part full name input and output each part on a new line.
*  Part 2 will take an input "x*y" and print the product of the two numbers.
*
*  Name: Kyle Kruse
*  Date: 04 Feb 2019
*  Project: Performance Lab 4D
*
*/
#include <stdio.h>

int main(void)
{
    //Initialize storage container sequence//
    char fName[21] = {0};
    char mName[21] = {0};
    char lName[21] = {0};
    int numOne = 0;
    int numTwo = 0;
    int numMaths = 0;

   //Names section//
    fprintf(stdout, "Please enter a name (First<tab>Middle<tab>Last): \n");     //Asks user to input a name//
    scanf("%20s\t%20s\t%20s", &fName, &mName, &lName);                          //Take user inputted names and store them in respective containers//
    fprintf(stdout, "Your name is: \n\t%s\n\t%s\n\t%s\n", fName, mName, lName); //Prints the name with a newline and tab between each//

    //Numbers section//
    fprintf(stdout, "Let's do some number maths now \n");                                    
    fprintf(stdout, "Please enter two numbers, with an asterisk bewteen (x*y) \n");          //Asks user to input two numbers//
    scanf("%d*%d", &numOne, &numTwo);                                                        //Assigns inputted numbers to variables//
    numMaths = numOne*numTwo;                                                                //Maths are done//
    fprintf(stdout, "The result of %d multiplied by %d is %d \n", numOne, numTwo, numMaths); //Prints the result//

    return 0;
}