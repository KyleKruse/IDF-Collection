/* This will take an input string and output it. 'Ole fget and fput Frisby they used to call me.
* Utilizes fgets() and fputs()
*
*  Name: Kyle Kruse
*  Date: 04 Feb 2019
*  Project: Performance Lab 4C
*
*/
#include <stdio.h>

int main(void)
{
    char userIn[10] = {0};                          //Sets variable//
    fprintf(stdout, "Please enter a string: \n");   
    fgets(userIn, 9, stdin);                        //Assigns user input to variable//
    fprintf(stdout, "Your string is: \n");
    fputs(userIn, stdout);                          //Prints the variable//

    return 0;
}