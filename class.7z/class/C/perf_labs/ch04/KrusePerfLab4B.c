/* This will take an input of one character and outpet the next sequential character.
* Utilizes getc() and putc()
*
*  Name: Kyle Kruse
*  Date: 04 Feb 2019
*  Project: Performance Lab 4B
*
*/
#include <stdio.h>

int main(void)
{
    int userIn = 0;                             //Sets variable//
	printf("Enter a single character: \n");     
    userIn = getc(stdin);                       //Gets the ASCII code for the first inputted character//
	printf("The next character is: \n");
    putc(userIn + 1, stdout);                   //Prints the next sequential ASCII character//

	return 0;
}