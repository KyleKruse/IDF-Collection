#define TWO_STRINGS(x, y) x##y
#define WITH_QUOTES(x) #x
#define BUFFER_SIZE 64

#include <stdio.h>

int main(void)
{
    //Let's define an array
    char theArray[BUFFER_SIZE] = {0};
    
    //Put the two strings with quotes into the array
    //theArray[0] = WITH_QUOTES(TWO_STRINGS(x, y));

    fprintf(stdout, "%s", TWO_STRINGS(input1, input2));

    return 0;
}