/* This will do things with arrays. Witchcraft.
*
*  Name: Kyle Kruse
*  Date: 30 Jan 2019
*  Project: Lab 3A
*
*/
#include <stdio.h>

int main(void)
{
    // Declares & initializes the ages array //
    int myArray [15] = {29, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28};
    
    // Prints the age array //
    int i = 0;
    printf("The ages are as follows:\n");
    for (i = 0; i < 15; i++)
    
    {
        printf("%d \n", myArray[i]);
    }

    // Declares & initializes the saying array //
    char bestSaying [] = { "They\nsay\nit\ndon't\nbe\nlike\nit\nis,\nbut\nit\ndo.\0"};
    
    // Prints the saying array //
    printf("My favorite saying is:\n%s\n", bestSaying);

    return 0;
}