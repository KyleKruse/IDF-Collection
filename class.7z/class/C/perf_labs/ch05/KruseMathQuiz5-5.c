/* This is some even more more maths.
*
*  Name: Kyle Kruse
*  Date: 05 Feb 2019
*  Project: Assignment Operators Quiz
*
*/
#include <stdio.h>
#include <math.h>

int main(void)
{
    int x = 9;
    int y = 3;

    //x *- y
    printf("%d *= %d is: \n\t   ", x, y);
    printf("%d \n", x*=y);
    x = 9;
    y = 3;
    //x /= y
    printf("%d /= %d is: \n\t   ", x, y);
    printf("%d \n", x/=y);
    x = 9;
    y = 3;
    //x %= y
    printf("%d %%= %d is: \n\t   ", x, y);
    printf("%d \n", x%=y);
    x = 9;
    y = 3;
    //x += y
    printf("%d += %d is: \n\t   ", x, y);
    printf("%d \n", x+=y);
    x = 9;
    y = 3;
    //x -= y
    printf("%d -= %d is: \n\t   ", x, y);
    printf("%d \n", x-=y);
    x = 9;
    y = 3;
    //x *= ++y
    printf("%d *= ++%d is: \n\t   ", x, y);
    printf("%d \n", x*=++y);
    x = 9;
    y = 3;
    //x /= y--
    printf("%d /= %d-- is: \n\t   ", x, y);
    printf("%d \n", x/=y);
    x = 9;
    y = 3;
    //x %= --x
    printf("%d %%= --%d is: \n\t   ", x, x);
    printf("%d \n", x%=--x);
    x = 9;
    y = 3;
    //x += --y
    printf("%d += --%d is: \n\t   ", x, y);
    printf("%d \n", x+=--y);
    x = 9;
    y = 3;
    //x -= y++
    printf("%d -= %d++ is: \n\t   ", x, y);
    printf("%d \n", x-=y++);
    x = 9;
    y = 3;
    //(y %= y) || (x /= x--)        // Bonus
    printf("(%d %%= %d) || (%d /= %d--) is: \n\t   ", y, y, x, x);
    printf("%d \n", ((y%=y)||(x/=x--)));

    return 0;
}