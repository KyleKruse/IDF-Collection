/* This is some even more maths.
*
*  Name: Kyle Kruse
*  Date: 05 Feb 2019
*  Project: Logical Operators Quiz
*
*/
#include <stdio.h>
#include <math.h>

int main(void)
{
    //Declare the things
    int x = 99;
    int y = 0;

    //x && y
    printf("%d && %d is %d \n", x, y, (x&&y));
    //y || x
    printf("%d || %d is %d \n", y, x, (y||x));
    //!y
    printf("!%d is %d \n", y, (!y));
    //y && 0
    printf("%d && 0 is %d \n", y, (y&&0));
    //x || 42
    printf("%d || 42 is %d \n", x, (x||42));
    //!x
    printf("!%d is %d \n", x, (!x));
    //x && x
    printf("%d && %d is %d \n", x, x, (x&&x));
    //y || y
    printf("%d || %d is %d \n", y, y, (y||y));
    //!1
    printf("!1 is %d \n", (!1));
    //1 && 1
    printf("1 && 1 is %d \n", (1&&1));
    //(0 && 1) || (2 && 3)        // Bonus
    printf("(0 && 1) || (2 && 3) is %d \n", (0&&1)||(2&&3));

    return 0;
}