/* Given an input of two legs, calculate the hypotenuse of a right triangle
*
*  Name: Kyle Kruse
*  Date: 05 Feb 2019
*  Project: Performance Lab 5A
*
*/
#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <math.h>

int main(void)
{
    //Initialize variables down yonder
    float leg1 = 0;
    float leg2 = 0;
    float legHyp = 0;

    //Prompts user for leg lengths & assigns them to the variables
    printf("Please enter the length of legs 1 and 2 with a space between them (x y): \n");
    scanf("%f %f", &leg1, &leg2);
    //Ensures values entered are both positive numbers
    if (leg1 <= 0 || leg2 <= 0)
    {
        printf("You suck. Enter values greater than zero \n");
        scanf("%f %f", &leg1, &leg2);
    }

    //Calculates the hypotenuse utilizing the Pythagorean Theorem
    legHyp = sqrt(leg1*leg1 + leg2*leg2);

    //Prints the result
    printf("The calculated hypotenuse using leg lengths %d and %d is: %d\n", (int)leg1, (int)leg2, (int)legHyp);

    return 0;
}