/* This is some maths.
*
*  Name: Kyle Kruse
*  Date: 05 Feb 2019
*  Project: Arithmetic Operators Quiz
*
*/
#include <stdio.h>
#include <math.h>

int main(void)
{
    int x = 7;
    int y = 4;
    float z = 0;

    //x * y//
    fprintf(stdout, "%d * %d equals %d \n", x, y, (x*y));
    //z = x / y//
    fprintf(stdout, "%d equals %d / %d \n", (x/y), x, y);
    //x % y//
    fprintf(stdout, "%d %c %d equals %d \n", x, 37, y, (x%y));
    //y + x//
    fprintf(stdout, "%d + %d equals %d \n", y, x, (y+x));
    //y - x//
    fprintf(stdout, "%d - %d equals %d \n", 7, x, (y-x));
    //-y//
    fprintf(stdout, "-y equals %d \n", (-y));
    //++x//
    fprintf(stdout, "++x equals %d \n", (++x));
    //y++//
    fprintf(stdout, "y++ equals %d \n", (y++));
    //x--//
    fprintf(stdout, "x-- equals %d \n", (x--));
    //--y//
    fprintf(stdout, "--y equals %d \n", (y--));
    //1 + 2 * (3 + y) + 5//
    fprintf(stdout, "1 + 2 * (3 + %d) + 5 equals %d \n", y, (1+2*(3+y)+5));

    return 0;
}