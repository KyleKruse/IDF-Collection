/* This is some more maths.
*
*  Name: Kyle Kruse
*  Date: 05 Feb 2019
*  Project: Relational Operators Quiz
*
*/
#include <stdio.h>
#include <math.h>

int main(void)
{
    //Declare things
    int x = 2;
    int y = 6;
    //y < x
    fprintf(stdout, "%d < %d = %d \n", y, x, (y<x) );
    //y <= x
    fprintf(stdout, "%d <= %d = %d \n",y, x, (y<=x));
    //y > x
    fprintf(stdout, "%d > %d = %d \n", y, x, (y>x));
    //y >= x
    fprintf(stdout, "%d >= %d = %d \n", y, x, (y>=x));
    //y == x
    fprintf(stdout, "%d == %d = %d \n", y, x, (y==x));
    //y != x
    fprintf(stdout, "%d != %d = %d \n", y, x, (y!=x));
    //2 == y
    fprintf(stdout, "2 == %d = %d \n", y, (2==y));
    //6 != x
    fprintf(stdout, "6 != %d = %d \n", x, (6!=x));
    //6 >= 2
    fprintf(stdout, "6 >= 2 = %d \n", (6>=2));
    //2 < 6
    fprintf(stdout, "2 < 6 = %d \n", (2<6) );
    //x != y != 3 >= x            // Bonus
    fprintf(stdout, "%d != %d != 3 >= %d = %d \n", x, y, x, (x!=y!=3>=x));

    return 0;
}