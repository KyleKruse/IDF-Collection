/* Initialize a 26 element int array to 0 and a char variable to 0
*  Use a do while loop to input, but not store, a string one character at a time from stdin without scanf()
*  Each time a character is entered:
*       Convert character to upper case with toupper()
*       Increment the corresponding array element if the user input is a letter
*       Ensure non-letters are safely handled (ctrl + d)
*  End the loop when a newline is read
*  Print the results using a for loop
*  
*  Name: Kyle Kruse
*  Date: 10 Feb 2019
*  Project: Performance Lab 7.3c
*
*/
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    //Initialize used variables
    int intArray[26] = {0};
    char variable = 0;
    int countVar = 0;

    //Prompts user for a string of letters
    fprintf(stdout, "Please enter a string of letters: \n");
    do
    {
        variable = getc(stdin);
        
        //If it's an uppercase letter, it's good to go. Add that to the array
        if (variable >= 65 && variable <= 90)
        {
            intArray[countVar] = variable;
            countVar++;
        }

        //If it's a lowercase letter, make it big, then add it to the array
        if (variable >= 97 && variable <= 122)
        {
            intArray[countVar] = toupper(variable);
            countVar++;
        }
        
    } 
    //Does the above until there's a nul or newline
    while (variable != '\n' && variable != '\0');
    
    //Prints the string all uppercasized
    fprintf(stdout, "Your string is: \n");
    int i = 0;
    for (i =0; i < countVar; i++)
    {
        putchar(intArray[i]);
    }
    
    return 0;
}