/* OCCUPANDI TEMPORIS
* Create a C file where your previous code is commented out and directly underneath, implement a for loop
*
*  Name: Kyle Kruse
*  Date: 08 Feb 2019
*  Project: Performance Lab 7.3a
*
*/
#include <stdio.h>

int main(void)
{
    
    // Declares & initializes the ages array //
    int myArray [15] = {29, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28};
    
    //////////THIS IS WHAT I DID INITIALLY//////////
    //int i = 0;
    //printf("The ages are as follows:\n");
    //for (i = 0; i < 15; i++)
    //
    //{
        //printf("%d \n", myArray[i]);
    //}
    
    //////////THIS IS WITHOUT A FOR LOOP//////////
    printf("%d \n", myArray[0]);
    printf("%d \n", myArray[1]);
    printf("%d \n", myArray[2]);
    printf("%d \n", myArray[3]);
    printf("%d \n", myArray[4]);
    printf("%d \n", myArray[5]);
    printf("%d \n", myArray[6]);
    printf("%d \n", myArray[7]);
    printf("%d \n", myArray[8]);
    printf("%d \n", myArray[9]);
    printf("%d \n", myArray[10]);
    printf("%d \n", myArray[11]);
    printf("%d \n", myArray[12]);
    printf("%d \n", myArray[13]);
    printf("%d \n", myArray[14]);

    return 0;
}