/* Given two inputted numbers, swap the largest number.
*
*  Name: Kyle Kruse
*  Date: 08 Feb 2019
*  Project: Performance Lab 7.2C
*
*/
#include <stdio.h>
#include <math.h>
#include <stdint.h>

int main(void)
{
    //Initialize used variables
    uint32_t num1 = 0;
    uint32_t num2 = 0;
    uint32_t num3 = 0;
    uint32_t temp = 0;

    //Prompts user for some maths
    fprintf(stdout, "Please enter two numbers seperated by a space (# #): \n");
    fscanf(stdin, "%u %u", &num1, &num2);

    //No same numbers, nerd
    if (num1 = num2)
    {
        fprintf(stdout, "ERROR: Numbers are the same");
    }

    else if (num1 )
    {
        fprintf(stdout, "We're working with %u and %u. There's also a 0 hanging out somewhere. \n", num1, num2);

    }







    return 0;
}