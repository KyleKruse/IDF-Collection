/* Initialize a nul terminated char array with multiple phrases separated by newlines (\n)
*  Test the char array with puts()
*  Write a while loop that only prints the first line and stops at a nul character
*  
*  Name: Kyle Kruse
*  Date: 10 Feb 2019
*  Project: Performance Lab 7.3b
*
*/
#include <stdio.h>

int main(void)
{
    //Initialize used variables
    char phrases[128] = {"this is a test\nsecond line\0"};
    int counter = 0;

    //Print the phrase so until there's a nul or newline
    fprintf(stdout, "phrase is: \n");
    while (phrases[counter] != '\0' && phrases[counter] != '\n')
    {
        putchar(phrases[counter]);
        counter ++;
    }

    return 0;
}