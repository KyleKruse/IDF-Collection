/* Given an inputted number, output the binary representation of it.
*
*  Name: Kyle Kruse
*  Date: 07 Feb 2019
*  Project: Performance Lab 7.2A
*
*/
#include <stdio.h>
#include <math.h>

int main(void)
{
    //Initialize zeroized array with a size of 64
    char newArray[64] = {0};
    
    //Prompt user for a string input & assigns it to the array
    fprintf(stdout, "Please input a string: \n");
    fscanf(stdin, "%s", &newArray);

    //If the first character of the string is a letter (ASCII code 16-126), print the string
    if ((newArray[0] >= 32) && (newArray[0] < 126))
    {
        fprintf(stdout, "%s", newArray);
    }

    return 0;
}