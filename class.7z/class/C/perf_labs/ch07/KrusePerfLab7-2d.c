/* I can haz do the arithmetics
*
*  Name: Kyle Kruse
*  Date: 08 Feb 2019
*  Project: Performance Lab 7.2D
*
*/
#include <stdio.h>
#include <math.h>

int main(void)
{
    //Initialize variables
    float num1 = 0;
    float num2 = 0;
    char mathsign = 0;

    //Invoke obtanium.exe to gather number resource from Layer 8 device
    fprintf(stdout, "Please input a simple math equation with two numbers (# + #) \n");
    fscanf(stdin, "%d %c %d", &num1, &mathsign, &num2);
    mathsign = (int)mathsign;

    //Math sequence below
    switch (mathsign)
    {   //Addition
        case 43:
            fprintf(stdout, "= %d", (num1 + num2));
            break;
        
        //Subtraction
        case 45:
            fprintf(stdout, "= %d", (num1 - num2));
            break;
        
        //Multiplication
        case 42:
            fprintf(stdout, "= %d", (num1 * num2));
            break;
        
        //Division
        case 47:
            fprintf(stdout, "= %.2f", (num1 / num2));
            break;
    
        default:
            fprintf(stdout, "ERROR: you suck");
            break;
    }
    return 0;
}