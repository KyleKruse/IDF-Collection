/* Input an unsigned integer "x"
*  Print the first 10-20 positive integers that x is divisible by utilizing the mod operator (not the most efficient)
*  Repeat this process
*  Immediately stop this process when the user inputs an integer above 999
*  Ignore any "divide by 0" errors using continue
*  
*  Name: Kyle Kruse
*  Date: 10 Feb 2019
*  Project: Performance Lab 7.4a
*
*/
#include <stdio.h>
#include <math.h>
#include <stdint.h>

int main(void)
{
    //Initialize used variables
    uint32_t x = 0;
    int divisible[64] = {0};
    int counter = 0;
    int i = 0;

    //Requests user input of a number less than 1000
    fprintf(stdout, "Please enter a positive number less than 1000: \n");
    fscanf(stdin, "%i", &x);

    //To catch them cheeky jokesters entering negative numbers or numbers greater than 999
    while (x <= 0 || x > 999)
    {
        fprintf(stdout, "Read the instructions! \n");
        fscanf(stdin, "%i", &x);
    }
    //Iterates from 0 to 20
    for (i = 0; i < 20; i++)
    {
        //Had to include that sweet continue
        if (i == 0)
        {
            continue;
        }
        //If there's no remainder, it's divisible. Add that to the array
        if ((x % i) == 0)
        {
            divisible[counter] = i;
            counter++;
        }

    }
    
    //Prints the divisible characters stored in the array
    fprintf(stdout, "%i is divisible by: \n", x);
    i = 0;
    counter = counter - 1;
    for (i = 0; i <= counter; i++)
    {
        fprintf(stdout, "%i, ", divisible[i]);
    }

    return 0;
}