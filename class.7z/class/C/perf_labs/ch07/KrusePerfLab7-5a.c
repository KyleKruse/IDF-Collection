/* Goal: Print all the even or odd numbers from 0 to 100
*  Prompt the user for input to indicate odds or evens
*  Loop from 0 to 100 and print all indicated numbers
*  Use an IF statement to check if even or odd
*  
*  Name: Kyle Kruse
*  Date: 10 Feb 2019
*  Project: Performance Lab 7.4a
*
*/
#include <stdio.h>
#include <math.h>

int main(void)
{
    //Initialize used variables
    char userChoice = 0;
    int userContinue = 1;
    int i = 0;

    fprintf(stdout, "We're going to print the numbers from 0 to 100. \n");
    
    //Does the things until user requests not to
    do
    {
        //Obtains user's choice of even or odd number display
        fprintf(stdout, "Would you like the even(e) or odd(o) numbers? \n");
        fscanf(stdin, "%c", &userChoice);
        //For the odd numbers
        if (userChoice == 'o')
        {
            i = 0;
            fprintf(stdout, "The odd numbers from 0 to 100 are: \n");
            //For loop version
            for (i = 0; i < 100; i++)
            {
                    i = i + 1;
                    fprintf(stdout, "%i ", i);
            }
            //Does thy wish to continue?
            fprintf(stdout, "\nContinue? Yes(1) or No(0) \n");
            fscanf(stdin, "%i", &userContinue);
        }
        //For the even numbers
        if (userChoice == 'e')
        {
            i = 2;
            fprintf(stdout, "The even numbers from 0 to 100 are: \n");
            //While loop version
            while (i < 101)
            {
                fprintf(stdout, "%i ", i);
                i = i + 2;
            }
            //Does thy wish to continue?
            fprintf(stdout, "\nContinue? Yes(1) or No(0) \n");
            fscanf(stdin, "%i", &userContinue);
        }
    }
    //If user enters a 0 after getting some sweet numbers, it will stop.
    while (userContinue == 1);

    return 0;
}