/* Given an inputted number, use a bitwise operation to check if it's positive or negative.
*  If negative, print value in binary and use a bitwise operation to flip a bit, making it negative.
*
*  Name: Kyle Kruse
*  Date: 08 Feb 2019
*  Project: Performance Lab 7.2B
*
*/
#include <stdio.h>
#include <math.h>

int main(void)
{
    //Initialize variables, assign 1 to bitcheck, shift bitcheck all the way to the left
    int userInt = 0;
    int bitCheck = 0x01;
    bitCheck = bitCheck << 15;

    //Prompts user to input a number
    fprintf(stdout, "Please input an integer \n");
    fscanf(stdin, "%d", &userInt);

    //Checks if the leftmost bit is a 1, meaning the number is negative
    if ((userInt & bitCheck) > 0)
    {
        fprintf(stdout, "The number is negative! \n");
    }
    else
    {
        //Prints out the binary 1's and 0's
        fprintf(stdout, "Binary representation of original number: \n");
        while (bitCheck > 0)
        {
            if ((userInt & bitCheck) > 0)
            {
                fprintf(stdout, "1");
            }
            else
            {
                fprintf(stdout, "0");
            }
    
            //Shifts bitChecker bit one position to the right
            bitCheck = bitCheck >> 1;
        }
        fprintf(stdout, "\nBinary representation after flip: \n");
        
        //Re-assign bitcheck value to 1 & shift it all the way to the left
        bitCheck = 0x01;
        bitCheck = bitCheck << 15;
        userInt = userInt | bitCheck;
        
        //Prints out the new binary 1's and 0's
        while (bitCheck > 0)
        {
            if ((userInt & bitCheck) > 0)
            {
                fprintf(stdout, "1");
            }
            else
            {
                fprintf(stdout, "0");
            }
    
            //Shifts bitChecker bit one position to the right
            bitCheck = bitCheck >> 1;
        }
    }
    return 0;
}