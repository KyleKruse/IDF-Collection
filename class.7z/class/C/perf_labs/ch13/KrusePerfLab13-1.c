/*
PERFORMANCE LAB 1
Follow instructions below!
The basis of this lab is simple... allocate a section of memory that will
hold a string (your first name). Print the name out, then cleanup the memory and exit.

---------------------------------
| Name: Kyle Kruse              |
| Date: 25 Feb 2019             |
| Project: Performance Lab 13-1 |
---------------------------------

*/

//TODO: Include needed headers


int main(void)
{
    //TODO: Create a string containing your first name

    //TODO: Get the size of this string

    //TODO: Declare a char pointer *str



    //TODO: Allocate a section of memory of type char
    //TODO: Set the size of this allocated space to 40 bytes
    //TODO: Asign the address of this allocated space to the pointer value


    //TODO: Copy your name into the allocated space using strcpy()

    //TODO: Print out your name that is stored in the allocated memory space

    //TODO: Reallocate the memory space using the size of the string rather than 40 bytes
    //TODO: Print out the string again


}