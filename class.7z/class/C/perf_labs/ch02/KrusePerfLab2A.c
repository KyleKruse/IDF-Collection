#include <stdio.h>

int main(void)
{
    /******** VARIABLE INITIALIZATION SEQUENCE COMMENCING BELOW ********/
    int integerNum = 1;
    float floatNum = 4.20;
    double doubleNum = 3.33333333;
    char charChar = '^';

    /******** DO THE THINGS ********/
    printf("size of int is %d \n", sizeof(integerNum));
    printf("size of float is %d \n", sizeof(floatNum));
    printf("size of double is %d \n", sizeof(doubleNum));
    printf("size of char is %d \n", sizeof(charChar));

    return 0;
}