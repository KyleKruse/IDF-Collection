/* This will cast and print different types of data.
*
*  Name: Kyle Kruse
*  Date: 29 Jan 2019
*  Project: Lab 2A
*
*/
#include <stdio.h>

int main(void)
{
    /* Declare/Initialize variables */
    int intNum = 42;
    float floatNum = 9.99;
    double doubleNum = 6.669420;
    char character = 'Y';

    /* Cast & print the helpful */
    printf("int -> float = %d \n", (float)intNum);
    printf("int -> char = %d \n", (char)intNum);
    printf("float -> double = %d \n", (double)floatNum);
    printf("double -> float = %d \n", (float)doubleNum);
    printf("char -> int = %d \n", (int)character);
    printf("63 -> char = %c \n", (char)63);

    return 0;
}