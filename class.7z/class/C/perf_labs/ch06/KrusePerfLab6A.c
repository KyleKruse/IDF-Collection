/* Given an inputted number, output the binary representation of it.
*
*  Name: Kyle Kruse
*  Date: 07 Feb 2019
*  Project: Performance Lab 6A
*
*/
#include <stdio.h>
#include <inttypes.h>
#include <math.h>

int main(void)
{
    //Initialize variables & shift bitChecker bit all the way to the left
    uint32_t userInput = 0;
    uint32_t bitChecker = 0x01;
    bitChecker = bitChecker << 31;

    //Prompts user for a positive number and assigns it to userInput
    printf("Please enter a positive number: \n");
    fscanf(stdin, "%u", &userInput);
    
    //Catches negative number/zero input and re-prompts for a postive number
    while ((int)userInput <= 0)
    {
        printf("Please enter a positive number: \n");
        fscanf(stdin, "%u", &userInput);
    }

    //Prints out the inputted number
    fprintf(stdout, "Your binary number is: \n");

    //Loop for checking bitChecker bit against userInput and outputs 0 or 1 depending on its value
    while (bitChecker > 0)
    {
        if ((userInput & bitChecker) > 0)
        {
            fprintf(stdout, "1");
        }
        else
        {
            fprintf(stdout, "0");
        }
    
        //Shifts bitChecker bit one position to the right
        bitChecker = bitChecker >> 1;
    }

    return 0;
}