/* 
PEFORMANCE LAB: CONTENT COPY CHAR-BY-CHAR

File I/O – putc()

“Content Copy”

    Open an existing file in read mode.
    Open a new file in write mode.
    Copy the existing file into the new file char-by-char.
    Close the existing file.
    Close and open the new file in read mode.
    Print the new file char-by-char.

---------------------------------
| Name: Kyle Kruse              |
| Date: 25 Feb 2019             |
| Project: Performance Lab 12-2 |
---------------------------------
*/

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE *fp1, *fp2;
    char ch;
 



}