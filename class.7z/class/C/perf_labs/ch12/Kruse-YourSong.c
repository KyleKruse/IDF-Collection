/* 
PERFOMANCE LAB: YOUR SONG

File I/O – fgets() “Your Song”

Save your favorite song into a text file.

Write a C program to:

    Open the file in read-only mode
    Read it line-by-line
    Print each line as it is read
    Close the file at the end

!! NOTE: File opens from working directory of this program. !!

---------------------------------
| Name: Kyle Kruse              |
| Date: 25 Feb 2019             |
| Project: Performance Lab 12-1 |
---------------------------------
*/

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE * myFile_ptr = fopen("./lyrics.txt", "r"); // Open file as read-only. 
    char tempBuff[256] = { 0 };	// Temporary buffer to store read lines
    char * tempReturnValue = tempBuff; // Holds fgets() return value
    if (myFile_ptr != NULL) 	// Verify fopen() succeeded… 
    {
        printf("File opening sequence successful! Lyrics are as follows: \n");
        while (tempReturnValue) // Continue reading until return value is NULL
        {
            tempReturnValue = fgets(tempBuff, 256, myFile_ptr);
            if (tempReturnValue) 	// If EOF hasn’t been reached…
            {
                puts(tempBuff);	// …print the buffer
            }
        }
        fclose(myFile_ptr); // Close the file
    }
    else 
        printf("Error occurred while trying to open file. #RIPinpeaces \n");
        return EXIT_FAILURE; // 
    return 0;
}