/* This program will calculate which two of three faces are the closest match.
*
*  Name: Kyle Kruse
*  Date: 17 Apr 2019
*  Project: Facial Recognition
*
*/
#include <stdio.h>
#include <math.h>

int main(void)
{
    // Variable jail
    float eye1,eye2,eye3,chin1,chin2,chin3,diff12,diff13,diff23;

    // Gather user input
    // Person 1
    printf("#1 Please input the Outer Eye Distance and Nose/Chin Distance ratios\n");
    printf("Example: '4.5 3.6' (no quotes)\n > ");
    fscanf(stdin, "%f %f", &eye1, &chin1);
    printf("\n");
    // Person 2
    printf("#2 Please input the Outer Eye Distance and Nose/Chin Distance ratios\n");
    printf("Example: '4.5 3.6' (no quotes)\n > ");
    fscanf(stdin, "%f %f", &eye2, &chin2);
    printf("\n");
    // Person 3
    printf("#3 Please input the Outer Eye Distance and Nose/Chin Distance ratios\n");
    printf("Example: '4.5 3.6' (no quotes)\n > ");
    fscanf(stdin, "%f %f", &eye3, &chin3);
    printf("\n");

    // Generate ratios & differences between them
    diff12 = fabs((eye1/chin1) - (eye2/chin2));
    diff13 = fabs((eye1/chin1) - (eye3/chin3));
    diff23 = fabs((eye2/chin2) - (eye3/chin3));

    // Find the smallest difference between ratios and returns result
    if (diff12 < diff13 && diff12 < diff23)
    {
        printf("Pictures 1 and 2 are the closest match.\n");
    }

    else if (diff13 < diff12 && diff13 < diff23)
    {
        printf("Pictures 1 and 3 are the closest match.\n");
    }

    else if (diff23 < diff12 && diff23 < diff13)
    {
        printf("Pictures 2 and 3 are the closest match.\n");
    }

    else
    {
        printf("Something went wrong!\n");
    }
    
    return 0;
}