/* This program will import hurricane stats from a .txt file and output information.
*
*  Name: Kyle Kruse
*  Date: 18 Apr 2019
*  Project: Hurricane
*
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    // Variable Jail
    int IDnum[64] = {0};
    int peakWind[64] = {0};
    int category[64] = {0};
    int i,indexer,highest = 0;
    
    printf("Before file stuff \n");
    // File operations
    FILE *file_ptr = fopen("./storms1.txt", "r");
    
    printf("Prior to reading \n");
    if (file_ptr != NULL) // file opened, continue and read data
    {
        printf("Before while loop\n");
        // Reads ID number and peak wind speed from file into respective arrays 
        while (fscanf(file_ptr,"%i %i", &IDnum[indexer], &peakWind[indexer]) == 2)
        {
            indexer++;
        }
        printf("After while loop\n");
        fclose(file_ptr); // Always fclose anything you fopen
    }
    
    else // file couldn't be opened
    {
        printf("Error occurred while trying to open file. #RIPinpeaces \n");
    }
    printf("After reading\n");
    
    
    printf("After closing\n");

    // Add in the categories based on peak wind speed
    printf("Categories beforehand \n");
    for (i=0; i < indexer; i++)
    {
        if (peakWind[i] > highest) // holds the ID with highest peak wind speed
        {
            highest = IDnum[i];
        }
        if (peakWind[i] < 74) // Not a hurricane
        {
            category[i] = 0;
        }
        if (peakWind[i] >= 74 && peakWind[i] <= 95) // Category 1
        {
            category[i] = 1;
        }
        if (peakWind[i] >= 96 && peakWind[i] <= 110) // Category 2
        {
            category[i] = 2;
        }
        if (peakWind[i] >= 111 && peakWind[i] <= 129) // Category 3
        {
            category[i] = 3;
        }
        if (peakWind[i] >= 130 && peakWind[i] <= 156) // Category 4
        {
            category[i] = 4;
        }
        if (peakWind[i] > 156) // Category 5, hide yo kids
        {
            category[i] = 5;
        }
    }
    
    // Print out result
    fprintf(stdout, "ID Number     Peak MPH     Category\n");
    for (i=0; i < indexer; i++)
    {
        if (IDnum[i] == highest) // Puts the asterisk on the ID number with the highest peak wind
        {
            fprintf(stdout, "%i*           %i           %i\n",IDnum[i], peakWind[i], category[i]);
        }
        else // Just prints the info for all others
        {
            fprintf(stdout, "%i           %i           %i\n",IDnum[i], peakWind[i], category[i]);
        }
    }

    return 0;
}