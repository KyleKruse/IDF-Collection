/* This program will calculate the distance between two points.
*
*  Name: Kyle Kruse
*  Date: 17 Apr 2019
*  Project: Distance between two points
*
*/
#include <stdio.h>
#include <math.h>

int main(void)
{
    float x1,x2,y1,y2,side1,side2,answer;

    // Gather input from the user and assign values to the respective variables
    printf("Please input the first x value\n");
    fscanf(stdin, "%f", &x1);
    printf("Please input the first y value\n");
    fscanf(stdin, "%f", &y1);
    printf("Please input the second x value\n");
    fscanf(stdin, "%f", &x2);
    printf("Please input the second y value\n");
    fscanf(stdin, "%f", &y2);
    printf("\n");

    // Calculate triangle's side lengths
    side1 = fabs(x1 - x2);
    side2 = fabs(y1 - y2);

    // Calculate hypotenuse/distance between points
    answer = sqrt(pow(side1, 2) + pow(side2, 2));

    // Print the answer
    printf("The distance between (%.2f,%.2f) and (%.2f,%.2f) is: %.2f\n\n", x1, x2, y1, y2, answer);

    return 0;
}