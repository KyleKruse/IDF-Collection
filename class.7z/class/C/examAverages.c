#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main (void)
{
    int currentScore = 0;
    int numPassed = 0;
    int numFailed = 0;
    int totalTests = 0;
    int keepGoing = 1;
    int i = 1;

    //Asks for user to input scores
    printf("NOTE: To stop inputting scores, press [X] \n");
    printf("Please enter each test score followed by [Enter]: \n");
    while (keepGoing > 0 && totalTests < 10)
    {
        printf("Test %d: ", i);
        //fscanf(stdin, "%d", &currentScore); //obtains user input and assigns it to currentScore
        currentScore = getchar();
        
        if (currentScore == 120)
        {
            keepGoing = 0;
        }
        
        else if (currentScore == 49) //Passing score
        {
            numPassed++;
            totalTests++;
            i++;
            currentScore = 0;
        }
        else if (currentScore == 50) //Failing score
        {
            numFailed++;
            totalTests++;
            i++;
            currentScore = 0;
        }
        
        else // The user inputted something other than a 1 or 2
        {
            while (currentScore != 120 && currentScore != 49 && currentScore && 50)
                {
                    printf("You didn't input a 1, 2, or X. What do you think you're doing? \n");
                    currentScore = getchar();
                }
        }
    }
    
    if (totalTests > 0) // Prints results if there were entries made by the user
    {
        printf("\nOut of %d tests taken, there were: \n", totalTests);
        printf("  %d PASSES \n  %d FAILS \n", numPassed, numFailed);
        
        if (numPassed >= 8) // Bonus statement for 8 or more passing scores
        {
            printf("Bonus to instructor! \n\n");
        }
    }
    
    else // There wasn't any scores inputted
    {
        printf("Well, we really didn't do anything did we?");
    }

    return 0;
}