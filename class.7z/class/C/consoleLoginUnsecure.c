#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//UNSECURE VERSION

int main()
{
    char buff[15];
    int pass = 0;

    printf("Enter the password");
    gets(buff);

    if(strcmp(buff, "pass1234"))
    {
        printf("Wrong password");
    }
    else
    {
        printf("Correct password");
        pass = 1;
    }
    if(pass)
    {
        printf("Root priviveges");
    }

    return 0;
}