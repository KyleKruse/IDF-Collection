#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern int RPSgame(int userChoice, int npc)
{   
    char gimmeDat[50] = {0};
// MAIN GAME LOOP
    // NPC ROCK
    if (npc = 1)
        {
            switch (userChoice)
            {
                case 1:
                        strcpy(gimmeDat, "a omputer: Rock\tUser: Rock\tDRAW\n\0");
                        return gimmeDat[0];
                        break;
                case 2:
                        strcpy(gimmeDat, "b omputer: Rock\tUser: Paper\tWIN\n\0");
                        return gimmeDat[0];
                        break;
                case 3:
                        strcpy(gimmeDat, "c omputer: Rock\tUser: Scissors\tLOSS\n\0");
                        return gimmeDat[0];
                        break;
                default:
                        strcpy(gimmeDat, "d ame was whack\n\0");
                        return gimmeDat[0];
                        break;
            }
        }
    // NPC PAPER
    else if (npc = 2)
        {
            switch (userChoice)
            {
                case 1:
                        strcpy(gimmeDat, "e omputer: Paper\tUser: Rock\tLOSS\n\0");
                        return gimmeDat[0];
                        break;
                case 2:
                        strcpy(gimmeDat, "f omputer: Paper\tUser: Paper\tDRAW\n\0");
                        return gimmeDat[0];
                        break;
                case 3:
                        strcpy(gimmeDat, "g omputer: Paper\tUser: Scissors\tLWIN\n\0");
                        return gimmeDat[0];
                        break;
                default:
                        strcpy(gimmeDat, "h ame was whack\n\0");
                        return gimmeDat[0];
                        break;
            }
        }

    // NPC SCISSORS
    else if (npc = 3)
        {
            switch (userChoice)
            {
                case 1:
                        strcpy(gimmeDat, "i omputer: Scissors\tUser: Rock\tWIN\n\0");
                        return gimmeDat[0];
                        break;
                case 2:
                        strcpy(gimmeDat, "j omputer: Scissors\tUser: Paper\tLOSS\n\0");
                        return gimmeDat[0];
                        break;
                case 3:
                        strcpy(gimmeDat, "k omputer: Scissors\tUser: Scissors\tDRAW\n\0");
                        return gimmeDat[0];
                        break;
                default:
                        strcpy(gimmeDat, "l ame was whack\n\0");
                        return gimmeDat[0];
                        break;
            }
        }
}