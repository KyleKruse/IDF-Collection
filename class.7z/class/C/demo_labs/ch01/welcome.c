/*********************************************************************
/   AUTHOR: Instructor
/   COURSE: C Programming 
/   PROGRAM NAME: welcome.c
/   PROGRAM DESCRIPTION: Our very first program :) 
*********************************************************************/

#include "stdio.h"

int main()
{
	printf("Welcome to C Programming");
	
	return(0);
}