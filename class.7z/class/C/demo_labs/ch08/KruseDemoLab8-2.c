/* Replace all newline characters with spaces
*  Takes a pointer to a buffer containing a nul-terminated string
*  Replaces all newline characters with spaces and returns the number of newline characters changed
*
*  Name: Kyle Kruse
*  Date: 11 Feb 2019
*  Project: Demonstration Lab 8-2
*
*/
# include <stdio.h>
int remove_newline();

int main(void)
{
    int remove_newline();


    return 0;
}

int remove_newline(char * buffer)
{
    char strArray[128] = {"This is a test\nSentence 2\nSentence3"};
    int i = 0;

    for (i=0; i < 128; i++)
    {
        if ((65 <=strArray[i] <= 90) || (97 <= strArray[i] <=122) || (strArray[i] == 32))
        {
            fprintf(stdout, "%c", strArray[i]);
        }

        if (strArray == "\n")
        {
            fprintf(stdout, " ");
        }
 getchar() != '\n' );
    }

    
    
    
    return 0;
}