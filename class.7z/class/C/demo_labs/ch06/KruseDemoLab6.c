/* Given an inputted number, calculate and output a bitwise shift right.
*
*  Name: Kyle Kruse
*  Date: 07 Feb 2019
*  Project: Performance Lab 6A
*
*/
#include <stdio.h>
#include <math.h>
#include <inttypes.h>

int main(void)
{
    uint32_t userInput = 0;
    uint32_t tempNum = 0;

    printf("Please enter a positive number: \n");
    scanf("%u", &tempNum);
    if (tempNum <= 0)
    {
        printf("Actually input a positive number");
        scanf("%u", tempNum);
    }

    tempNum = userInput & 0x0000000F;
    printf("%d", tempNum);

    return 0;
}