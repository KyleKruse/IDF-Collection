#include <stdio.h>

int main() {
    FILE *pFile;
    char input[81];

    pFile = fopen("C:/Users/DOTlaptop/Desktop/words.txt", "r");

    if(pFile != NULL)
    {
        //process file
        while(!feof(pFile)) 
        {
            fgets(input, 81, pFile);
            printf("%s", input);
        }
        fclose(pFile);
    }
    else
    {
        //IO Error
        printf("IO Error: Problem with file");
    }
    return 0;
}