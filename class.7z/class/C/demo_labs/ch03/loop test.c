
#include <stdio.h>

int main(void)
{
    int myIntArray[10] = {0};
    int i = 0;
    for (i = 0; i < 10; i++)
    {
        myIntArray [i] = 100;
    }
    printf("%d \n", myIntArray[2]);

    return 0;

}