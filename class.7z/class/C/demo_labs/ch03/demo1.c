/* This is Demo Lab 1
*
*  Name: Kyle Kruse
*  Date: 30 Jan 2019
*  Project: Demo Lab 1
*
*/

#include <stdio.h>

int main(void)
{
	// Declare & initialize the 3 arrays //
	int myIntArray[10] = {0};
	int i = 0;
    for (i = 0; i < 10; i++)
    {
        myIntArray[i] = 100;
    }
	float myFloatArray[5] = {1.0, 2.0, 3.0, 4.0, 5.0};
	char myCharArray[256] = {0};
	
	printf("%d \n", myIntArray[2]);
	printf("%f \n", myFloatArray[2]);
	printf("%c \n", myCharArray[2]);

    // myIntArray manipulation //
	// myIntArray[y] = (y + 1) * 10 //
	int y = 0;
	int x = (y + 1) * 10;
	for (y = 0; y < 10; y++)
    {
        myIntArray[y] = x;
    }

	// myFloatArray manipulation //
	i = 0;
	y = myFloatArray[i];
	x = y * 1.1;
	for (i = 0; i < 10; i++)
    {
        myFloatArray[i] = x;
    }

	//myCharArray manipulation //
	myCharArray[0] = 'K';
	myCharArray[1] = 'R';
	myCharArray[2] = 'U';
	myCharArray[3] = 'S';
	myCharArray[4] = 'E';

	printf("%d \n", myIntArray[2]);
	printf("%f \n", myFloatArray[2]);
	printf("%c \n", myCharArray[2]);

	return 0;

}