/* This is for practicing flags, field width, and precision for printf.
*
*  Name: Kyle Kruse
*  Date: 04 Feb 2019
*  Project: Classroom Exercise
*
*/
#include <stdio.h>

int main(void)
{
    printf("Number 1: %f\n", 1.2);
    printf("Number 2: %+8.4f\n", -1.798);
    printf("Number 3: % 7.2f\n", 0.987654321);
    printf("Number 4: %-6.1f is yours\n", 13.37);
    printf("Number 5: Yours is %05.2f\n", 1.2345);
    printf("Number 6: %s\n", "Hello World!\0");
    printf("Number 7: %9.5s\n", "Hello world!\0");
    printf("Number 8: %016.11s\n", "Hello world!\0");

    return 0;
}