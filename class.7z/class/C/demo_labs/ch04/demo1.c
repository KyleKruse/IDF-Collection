/* This is for practicing flags, field width, and precision for printf.
*
*  Name: Kyle Kruse
*  Date: 04 Feb 2019
*  Project: Classroom Exercise
*
    OBJECTIVE:
    Read a string into a char array
    Specify a field-width to protect against buffer overflow
    Ensure the field-width leaves room for the nul-terminator
    Stop reading at the first capital letter or new line

*
*/
#include <stdio.h>

int main(void)
{
	char inputBuffer[256] = {0};

	printf("Enter a string but don't use any capital letters. \n");
	scanf("%255[^A-Z\n]s", inputBuffer);
	printf("Your lower case string was: \n%s", inputBuffer);

	return 0;
}