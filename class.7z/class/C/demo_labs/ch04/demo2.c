/* This is for practicing flags, field width, and precision for printf.
*
*  Name: Kyle Kruse
*  Date: 04 Feb 2019
*  Project: Classroom Exercise
*
    OBJECTIVE:
    Read three ints, representing the date, from one line
    Format the input so the integers are separated by a dash (-) as <mm>-<dd>-<yyyy>
    Output the results as a date with leading zeros <mm>/<dd>/<yyyy>
    Specify the field width of the output appropriately


*
*/
#include <stdio.h>

int main(void)
{
	char testCase[] = {'A', 'B', 'C', 0};
	double currentTemp[] = {100.1234, 99.876543, 133.7};
	int numOfRuns[] = {3, 4, 5};
	
	printf("%-12Test Case %-12Temp(F) %12-# of Runs\n");
	printf("%-12c %-012.2f %-12d\n", testCase[0], currentTemp[0], numOfRuns[0]);
	printf("%-12c %-012.2f %-12d\n", testCase[1], currentTemp[1], numOfRuns[1]);
	printf("%-12c %-012.2f %-12d\n", testCase[2], currentTemp[2], numOfRuns[2]);
	return 0;
}